﻿编译
make clean 
make

运行
sudo python topo.py
>> xterm r1 r2 r3 r4

r* >> ./mospfd

